package com.example.demotask.model

class ExploreModel(var userImage: Int) {
}